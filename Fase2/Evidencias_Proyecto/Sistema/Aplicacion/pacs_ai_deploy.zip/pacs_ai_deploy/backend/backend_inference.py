import os, io, json, numpy as np, requests, pydicom, tensorflow as tf
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
ORTHANC_URL=os.getenv('ORTHANC_URL','http://orthanc:8042')
ORTHANC_USER=os.getenv('ORTHANC_USER','orthanc')
ORTHANC_PASS=os.getenv('ORTHANC_PASS','orthanc')
MODEL_PATH='best_cnn3d.keras'; META_PATH='model_meta.json'
def sigmoid_focal_loss(y_true,y_pred,alpha=0.25,gamma=2.0,eps=1e-7):
    y_true=tf.cast(y_true,tf.float32)
    y_pred=tf.clip_by_value(tf.cast(y_pred,tf.float32),eps,1.-eps)
    ce=-(y_true*tf.math.log(y_pred)+(1-y_true)*tf.math.log(1-y_pred))
    p_t=y_true*y_pred+(1-y_true)*(1-y_pred)
    a_t=y_true*alpha+(1-y_true)*(1-alpha)
    return tf.reduce_mean(a_t*tf.pow(1-p_t,gamma)*ce)
model=tf.keras.models.load_model(MODEL_PATH,compile=False)
model.compile(optimizer='adam',loss=sigmoid_focal_loss,metrics=[tf.keras.metrics.AUC(name='auc')])
BEST_THR=0.5
if os.path.exists(META_PATH):
    with open(META_PATH) as f: BEST_THR=float(json.load(f).get('best_threshold',0.5))
app=FastAPI(title='PACS-AI Assist Inference')
class Req(BaseModel):
    StudyInstanceUID:str; SeriesInstanceUID:str
def _a(): return (ORTHANC_USER,ORTHANC_PASS)
@app.get('/status')
def st(): return {'ok':True,'thr':BEST_THR}
@app.post('/infer')
def inf(r:Req):
    s=requests.get(f'{ORTHANC_URL}/series',auth=_a()).json()
    sid=None
    for x in s:
        m=requests.get(f'{ORTHANC_URL}/series/{x}',auth=_a()).json()
        if m.get('MainDicomTags',{}).get('SeriesInstanceUID')==r.SeriesInstanceUID:
            sid=x;insts=m['Instances'];break
    if not sid: raise HTTPException(404,'Serie no encontrada')
    d=requests.get(f'{ORTHANC_URL}/instances/{insts[0]}/file',auth=_a())
    ds=pydicom.dcmread(io.BytesIO(d.content))
    a=ds.pixel_array.astype('float32');a=(a-a.mean())/(a.std()+1e-6)
    v=np.tile(a[None,...],(64,1,1));p=np.zeros((64,64,64),'float32');h,w=min(64,v.shape[1]),min(64,v.shape[2])
    p[:,:h,:w]=v[:,:h,:w]
    pr=float(model.predict(p[None,...,None],verbose=0).ravel()[0])
    return {'series':r.SeriesInstanceUID,'proba':pr,'pred':int(pr>=BEST_THR),'thr':BEST_THR}
